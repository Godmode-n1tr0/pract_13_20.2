﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract_20_1
{
    public abstract class Spectacl
    {
        private string _title;
        private string _genre;
        private string _author;
        private string _director;

        public static List<Spectacl> AllSpectacles = new List<Spectacl>();

        protected Spectacl(string title, string genre, string author, string director)
        {
            string errors = string.Empty;
            errors += Validation.ValidateString(title, "Название");
            errors += Validation.ValidateString(genre, "Жанр");
            errors += Validation.ValidateString(author, "Автор");
            errors += Validation.ValidateString(director, "Режиссер");

            int count = 0;
            if (!string.IsNullOrEmpty(errors))
            {
                count++;
                MessageBox.Show(errors);
            }

            _title = title;
            _genre = genre;
            _author = author;
            _director = director;

            AllSpectacles.Add(this);
            if (count > 0)
            {
                AllSpectacles.RemoveAt(0);
            }
        }

        public string Title => _title;
        public string Genre => _genre;
        public string Author => _author;
        public string Director => _director;

        public abstract string Info();

    }
}
