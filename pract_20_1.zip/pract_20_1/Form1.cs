﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pract_20_1
{
    public partial class Form1 : Form
    {
        int count = 0;
        int count2 = 0;
        public Form1()
        {
            InitializeComponent();
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                label1.Visible = false;
                comboBox1.Visible = false;
                button1.Visible = false;
                groupBox1.Visible = true;

            }
            if (comboBox1.SelectedIndex == 1)
            {
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox10.Clear();
                label1.Visible = false;
                comboBox1.Visible = false;
                button1.Visible = false;
                groupBox2.Visible = true;

            }
        }
        private void LoadSpectacles(bool isLocal)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            if (isLocal)
            {
                dataGridView1.ColumnCount = 7;
                dataGridView1.Columns[0].HeaderText = "Тип";
                dataGridView1.Columns[1].HeaderText = "Название";
                dataGridView1.Columns[2].HeaderText = "Жанр";
                dataGridView1.Columns[3].HeaderText = "Автор";
                dataGridView1.Columns[4].HeaderText = "Режиссер";
                dataGridView1.Columns[5].HeaderText = "Театр";
                dataGridView1.Columns[6].HeaderText = "Кол-во показов";
            }
            else
            {
                dataGridView1.ColumnCount = 8;
                dataGridView1.Columns[0].HeaderText = "Тип";
                dataGridView1.Columns[1].HeaderText = "Название";
                dataGridView1.Columns[2].HeaderText = "Жанр";
                dataGridView1.Columns[3].HeaderText = "Автор";
                dataGridView1.Columns[4].HeaderText = "Режиссер";
                dataGridView1.Columns[5].HeaderText = "Дата начала";
                dataGridView1.Columns[6].HeaderText = "Дата конца";
                dataGridView1.Columns[7].HeaderText = "Площадка";
            }

            try
            {
                using (StreamReader file = new StreamReader("Spectacl.txt"))
                {
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        if ((line == "Местный спектакль" && isLocal) ||
                            (line == "Гастрольный спектакль" && !isLocal))
                        {
                            int fieldsCount = isLocal ? 7 : 8;
                            string[] rowData = new string[fieldsCount];
                            rowData[0] = line;

                            for (int i = 1; i < fieldsCount; i++)
                            {
                                rowData[i] = file.ReadLine();
                            }

                            dataGridView1.Rows.Add(rowData);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при чтении файла: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            count++;
            if (count > 0)
            {
                button2.Enabled = false;
                count = 0;
            }
            string title = textBox1.Text;
            string genre = comboBox2.Text;
            string author = textBox2.Text;
            string director = textBox3.Text;
            DateTime start;
            DateTime end;
            string format = "dd.MM.yyyy";
            while (true)
            {
                if (DateTime.TryParseExact(textBox4.Text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out start))
                {
                    start = start.Date;
                    break;
                }
                MessageBox.Show("Некорректный формат даты. Используйте ДД.ММ.ГГГГ");
                return;
            }

            while (true)
            {
                if (DateTime.TryParseExact(textBox5.Text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out end))
                {
                    end = end.Date;
                    break;
                }
                MessageBox.Show("Некорректный формат даты. Используйте ДД.ММ.ГГГГ");
                return;
            }
            string venue = comboBox3.Text;
            var spectacle = new GSpectacl(title, genre, author, director, start, end, venue);
            MessageBox.Show("Спектакль создан!");   
            using (StreamWriter file = File.AppendText("Spectacl.txt"))
            {
                foreach (var spectakl in Spectacl.AllSpectacles)
                {
                    file.WriteLine(spectacle.Info());
                }
            }
            groupBox1.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }


        private void button3_Click(object sender, EventArgs e)
        {
            count2++;
            if (count2 > 0)
            {
                button3.Enabled = false;
                count2 = 0;
            }
            string title = textBox6.Text;
            string genre = comboBox5.Text;
            string author = textBox8.Text;
            string director = textBox10.Text;
            string theater = comboBox4.Text;
            int count = Convert.ToInt32(textBox7.Text);
            var spectacle = new MSpectacl(title, genre, author, director, theater, count);
            MessageBox.Show("Спектакль создан!");
            using (StreamWriter file = File.AppendText("Spectacl.txt"))
            {
                foreach (var spectakl in Spectacl.AllSpectacles)
                {
                    file.WriteLine(spectacle.Info());
                    file.WriteLine("#");
                }
            }
            groupBox2.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку для удаления");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int rowIndex = selectedRow.Index;
            if (MessageBox.Show("Удалить выбранный спектакль?", "Подтверждение",MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            dataGridView1.Rows.Remove(selectedRow);

            RewriteFileCompletely(rowIndex);

            dataGridView1.Refresh();
        }
        private void RewriteFileCompletely(int deletedRowIndex)
        {
            try
            {
                bool isLocal = comboBox6.SelectedIndex == 1;
                string currentType = isLocal ? "Местный спектакль" : "Гастрольный спектакль";
                int fieldsCount = isLocal ? 7 : 8;

                List<string> fileLines = File.ReadAllLines("Spectacl.txt").ToList();
                List<string> newFileContent = new List<string>();

                int currentIndex = 0;
                for (int i = 0; i < fileLines.Count; i++)
                {
                    if (fileLines[i] == currentType)
                    {
                        if (currentIndex == deletedRowIndex)
                        {
                            i += fieldsCount - 1;
                        }
                        else
                        {
                            for (int j = 0; j < fieldsCount && i + j < fileLines.Count; j++)
                            {
                                newFileContent.Add(fileLines[i + j]);
                            }
                            i += fieldsCount - 1;
                        }
                        currentIndex++;
                    }
                    else
                    {
                        newFileContent.Add(fileLines[i]);
                    }
                }

                File.WriteAllLines("Spectacl.txt", newFileContent);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}");
            }
        }
        private void Mestni()
        {
            LoadSpectacles(isLocal: true);
        }

        private void Gastroli()
        {
            LoadSpectacles(isLocal: false);
        }
        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox6.SelectedIndex == 0)
            {
                groupBox4.Visible = false;

                dataGridView1.Refresh();
                Gastroli();
                groupBox3.Visible = true;
            }
            if (comboBox6.SelectedIndex == 1)
            {
                groupBox3.Visible = false;
                dataGridView1.Refresh();
                Mestni();
                groupBox4.Visible = true;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            /*textBox20.Text;
            textBox19.Text;
            textBox22.Text;
            textBox23.Text;
            textBox24.Text;
            textBox25.Text;*/
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }
    }
}
