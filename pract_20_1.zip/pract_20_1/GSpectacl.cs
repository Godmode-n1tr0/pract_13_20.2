﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract_20_1
{
    public class GSpectacl : Spectacl
    {
        private DateTime _tourStart;
        private DateTime _tourEnd;
        private string _venue;

        public GSpectacl(string title, string genre, string author, string director, DateTime tourStart, DateTime tourEnd, string venue, bool checkDatesNotPast = false) : base(title, genre, author, director)
        {
            string errors = string.Empty;
            errors += Validation.ValidateDates(tourStart, tourEnd, "Дата начала", "Дата окончания", checkDatesNotPast);
            errors += Validation.ValidateString(venue, "Площадка");

            if (!string.IsNullOrEmpty(errors))
            {
                AllSpectacles.RemoveAt(0);
                MessageBox.Show(errors);
                return;
            }
            _tourStart = tourStart;
            _tourEnd = tourEnd;
            _venue = venue;
        }


        public DateTime TourStart => _tourStart;
        public DateTime TourEnd => _tourEnd;
        public string Venue => _venue;

        public override string Info()
        {
            return $"Гастрольный спектакль\n{Title}\n{Genre}\n{Author}\n{Director}\n{TourStart.ToString("dd.MM.yyyy")}\n{TourEnd.ToString("dd.MM.yyyy")}\n{Venue}";
        }
    }
}
